import java.util.*;

public class DistributedApple {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int ram = 50;
        int sham = 30;
        int rahim = 20;
        int weight = 0;
        List<Integer> list = new ArrayList<>();
        do {
            System.out.println("Enter apple weight in gram (-1 to stop ) : ");
            weight = sc.nextInt();
            if (weight == -1) {
                break;
            }
            list.add(weight);
        } while (weight != -1);
        calculatePercentage(ram, sham, rahim, list);
    }

    private static void calculatePercentage(int ram, int sham, int rahim, List<Integer> list) {
        double total = 0;
        List<Integer> ramList = new ArrayList<>();
        List<Integer> shamList = new ArrayList<>();
        List<Integer> rahimList = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            total += list.get(i);
        }
        double ramCount = (ram / 100.0) * total;
        double shamCount = (sham / 100.0) * total;
        double rahimCount = (rahim / 100.0) * total;
        double ramApple = 0;
        double shamApple = 0;
        double rahimApple = 0;
        Collections.sort(list, Collections.reverseOrder());
        for (int i = 0; i < list.size(); i++) {
            if (ramApple < ramCount && list.get(i) <= ramCount - ramApple) {
                ramApple += list.get(i);
                ramList.add(list.get(i));
            } else if (shamApple < shamCount && list.get(i) <= shamCount - shamApple) {
                shamApple += list.get(i);
                shamList.add(list.get(i));
            } else if (rahimApple < rahimCount && list.get(i) <= rahimCount - rahimApple) {
                rahimApple += list.get(i);
                rahimList.add(list.get(i));
            }
        }
        System.out.print("Ram : ");
        for (int i : ramList) {
            System.out.print(i + " ");
        }
        System.out.println();
        System.out.print("Sham : ");
        for (int i : shamList) {
            System.out.print(i + " ");
        }
        System.out.println();
        System.out.print("Rahim : ");
        for (int i : rahimList) {
            System.out.print(i + " ");
        }
    }
}