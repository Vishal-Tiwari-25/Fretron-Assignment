import java.util.*;

public class FindHomeCastle {
    private static final int BOARD_SIZE = 10;
    private static final int[] DX = {-1, 0, 0}; 
    private static final int[] DY = {0, -1, 1}; 

    private static class Coordinate {
        int x, y;

        public Coordinate(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public String toString() {
            return "(" + x + "," + y + ")";
        }
    }

    private static class Soldier {
        Coordinate coord;

        public Soldier(Coordinate coord) {
            this.coord = coord;
        }
    }

    private static class SpecialCastle {
        Coordinate coord;

        public SpecialCastle(Coordinate coord) {
            this.coord = coord;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of soldiers: ");
        int numSoldiers = scanner.nextInt();
        Soldier[] soldiers = new Soldier[numSoldiers];

        for (int i = 0; i < numSoldiers; i++) {
            System.out.print("Enter coordinates for soldier " + (i + 1) + ": ");
            String[] coords = scanner.next().split(",");
            int x = Integer.parseInt(coords[0]);
            int y = Integer.parseInt(coords[1]);
            soldiers[i] = new Soldier(new Coordinate(x, y));
        }

        System.out.print("Enter coordinates for special castle: ");
        String[] coords = scanner.next().split(",");
        int x = Integer.parseInt(coords[0]);
        int y = Integer.parseInt(coords[1]);
        SpecialCastle castle = new SpecialCastle(new Coordinate(x, y));

        List<List<Coordinate>> paths = findPaths(soldiers, castle);
        System.out.println("Thanks. There are " + paths.size() + " unique paths for your special castle");

        for (int i = 0; i < paths.size(); i++) {
            System.out.println("Path " + (i + 1));
            System.out.println("=======");
            for (Coordinate coord : paths.get(i)) {
                System.out.println(coord);
            }
        }
    }

    private static List<List<Coordinate>> findPaths(Soldier[] soldiers, SpecialCastle castle) {
        List<List<Coordinate>> paths = new ArrayList<>();
        boolean[][] visited = new boolean[BOARD_SIZE][BOARD_SIZE];

        dfs(soldiers, castle, new ArrayList<>(), visited, paths);
        return paths;
    }

    private static void dfs(Soldier[] soldiers, SpecialCastle castle, List<Coordinate> path, boolean[][] visited, List<List<Coordinate>> paths) {
        path.add(new Coordinate(castle.coord.x, castle.coord.y));
        if (castle.coord.x == 0) {
            paths.add(new ArrayList<>(path));
            path.remove(path.size() - 1);
            return;
        }

        for (int i = 0; i < 3; i++) {
            int newX = castle.coord.x + DX[i];
            int newY = castle.coord.y + DY[i];

            if (newX >= 0 && newX < BOARD_SIZE && newY >= 0 && newY < BOARD_SIZE && !visited[newX][newY]) {
                visited[newX][newY] = true;

                Soldier soldier = getSoldierAt(soldiers, newX, newY);
                if (soldier != null) {
                    castle.coord = new Coordinate(newX, newY);
                    dfs(soldiers, castle, path, visited, paths);
                    castle.coord = path.get(path.size() - 1);
                } else {
                  
                    castle.coord = new Coordinate(newX, newY);
                    dfs(soldiers, castle, path, visited, paths);
                    castle.coord = path.get(path.size() - 1);
                }

                visited[newX][newY] = false;
            }
        }
        path.remove(path.size() - 1);
    }

    private static Soldier getSoldierAt(Soldier[] soldiers, int x, int y) {
        for (Soldier soldier : soldiers) {
            if (soldier.coord.x == x && soldier.coord.y == y) {
                return soldier;
            }
        }
        return null;
    }
}

