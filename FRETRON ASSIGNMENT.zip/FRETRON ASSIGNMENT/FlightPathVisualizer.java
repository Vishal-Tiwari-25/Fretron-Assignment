import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

class FlightPathPanel extends JPanel {
    private List<List<Point>> flights;

    public FlightPathPanel(List<List<Point>> flights) {
        this.flights = flights;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Color[] colors = {Color.RED, Color.BLUE, Color.GREEN};
        int offset = 10;

        for (int i = 0; i < flights.size(); i++) {
            List<Point> flight = flights.get(i);
            g.setColor(colors[i % colors.length]);

            for (int j = 0; j < flight.size() - 1; j++) {
                Point start = flight.get(j);
                Point end = flight.get(j + 1);

                int xOffset = i * offset;
                int yOffset = i * offset;

                int startX = start.x * 100 + xOffset;
                int startY = start.y * 100 + yOffset;
                int endX = end.x * 100 + xOffset;
                int endY = end.y * 100 + yOffset;

                g.drawLine(startX, startY, endX, endY);
                g.fillOval(startX - 5, startY - 5, 10, 10);
                g.fillOval(endX - 5, endY - 5, 10, 10);
            }
        }
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(800, 600);
    }
}

public class FlightPathVisualizer {
    public static void main(String[] args) {
        List<Point> flight1 = new ArrayList<>();
        flight1.add(new Point(1, 1));
        flight1.add(new Point(2, 2));
        flight1.add(new Point(3, 3));

        List<Point> flight2 = new ArrayList<>();
        flight2.add(new Point(1, 1));
        flight2.add(new Point(2, 4));
        flight2.add(new Point(3, 2));

        List<Point> flight3 = new ArrayList<>();
        flight3.add(new Point(1, 1));
        flight3.add(new Point(4, 2));
        flight3.add(new Point(3, 4));

        List<List<Point>> flights = new ArrayList<>();
        flights.add(flight1);
        flights.add(flight2);
        flights.add(flight3);

        JFrame frame = new JFrame("Flight Path Visualizer");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new FlightPathPanel(flights));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
